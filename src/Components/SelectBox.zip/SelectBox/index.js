import React, { Component } from 'react'
import { Text, StyleSheet, Platform, View } from 'react-native'
import { COLORS } from '../../Components/color/'
import RNPickerSelect from 'react-native-picker-select';

export default class InputText extends Component {
    render() {
        const {
            icon,
            placeholder,
            onValueChange,
            value,
            error,
            items,
        } = this.props;
        return (
            <View style={styles.content}>
                <View style={styles.iconStyle}>
                    {icon &&
                        icon
                    }
                </View>
                <View
                    style={[
                        styles.input,
                        error ? {borderColor:COLORS.errorRed}:null
                    ]}
                >
                <RNPickerSelect
                    placeholder={placeholder}
                    value={value}
                    useNativeAndroidPickerStyle={false}
                    onValueChange={onValueChange}
                    items={items}
                />
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    content:{
        flex:1,
        flexDirection:'row'
    },
    input:{
        flex:1,
        padding:Platform.OS == 'ios' ? 15:5,
        paddingTop:Platform.OS == 'ios' ? 10:0,
        margin:5,
        marginBottom:15,
        fontSize:16,
        borderBottomWidth:1,
        borderColor:COLORS.paceholder,
        color:COLORS.textInput,
    },
    iconStyle:{
        justifyContent: "center",
        alignSelf:'center',
        width: 20,
        marginBottom:10,

    },
    errorText:{
        fontSize:10,
        color:'red',
        position:'absolute',
        right:0,
        bottom:-5
    }
})